/**
Justin Committe
 March 8, 2015
 goal3_Debug
 */
